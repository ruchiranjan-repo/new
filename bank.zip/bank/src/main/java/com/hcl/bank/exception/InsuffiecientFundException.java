package com.hcl.bank.exception;

public class InsuffiecientFundException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public InsuffiecientFundException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	
	

}
