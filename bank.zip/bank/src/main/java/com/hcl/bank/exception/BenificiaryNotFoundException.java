package com.hcl.bank.exception;

public class BenificiaryNotFoundException extends Exception {

	public BenificiaryNotFoundException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	private static final long serialVersionUID = 1L;
	
	

}
