package com.ecommercedemo.ecommerce;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ECommerceManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
