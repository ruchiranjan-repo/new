package com.ecommercedemo.ecommerce;

public class TestData {
	public static final String SHOP_NAME = "SHOPNAME";
	public static final String SHOP_LOCATION = "SHOPLOCATION";
	public static final String SHOP_DESC = "SHOP DESCRIPTION";
	public static final Double SHOP_AVG_RATING = new Double(4.4);
	public static final String USER_NAME = "USER NAME";
	public static final Double SHOP_FEEDBACK_RATING = new Double(4.4);
	public static final String SHOP_FEEDBACK_COMMENT = "FEEDBACK COMMENT";
	public static final Double SHOP_FEEDBACK_RATING1 = new Double(4.4);
	public static final String SHOP_FEEDBACK_COMMENT1 = "FEEDBACK COMMENT1";
	public static final Long PRODUCT_ID = 1L;
	public static final Long SHOP_ID = 1L;
	public static final Long CATEGORY_ID = 1L;
	public static final Long USER_ID = 1L;
	public static final Long SHOP_FEEDBACK_ID = 1L;
	public static final Long SHOP_FEEDBACK_ID2 = 2L;
	public static final Long ORDERDETAIL_ID = 1L;
	public static final Double PRODUCT_COST = 100D;
	public static final String PRODUCT_DESCRIPTION = "PRODUCT DESCRIPTION";
	public static final String CATEGORY_NAME = "CATEGORY NAME";
	public static final String CATEGORY_DESCRIPTION = "CATEGORY DESCRIPTION";

}
