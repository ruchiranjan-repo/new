package com.ecommercedemo.ecommerce.service;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;

import com.ecommercedemo.ecommerce.dto.ProductResponse;
import com.ecommercedemo.ecommerce.dto.ShopResponse;
import com.ecommercedemo.ecommerce.entity.Category;
import com.ecommercedemo.ecommerce.entity.Product;
import com.ecommercedemo.ecommerce.entity.ProductShopDetails;
import com.ecommercedemo.ecommerce.entity.Shop;
import com.ecommercedemo.ecommerce.exception.ProductNameNotFoundException;
import com.ecommercedemo.ecommerce.exception.ProductNotFoundException;
import com.ecommercedemo.ecommerce.repository.ProductRepository;
import com.ecommercedemo.ecommerce.repository.ProductShopDetailsRepository;

@SpringBootTest
public class ProductServiceTest {

	@Autowired
	private ProductService productService;

	@MockBean
	private ProductRepository productRepository;

	Product product, product1;

	Category category, category1;

	ProductShopDetails productShopDetails;
	@Autowired
	private ProductShopDetailsRepository productShopDetailsRepository;

	Shop shop;

	@BeforeEach
	public void setUp() {

		product = new Product();

		product.setProductCost(2000.0);
		product.setProductDescription("good looking");
		product.setProductName("Jeans Shirt");
		product1 = new Product();

		product1.setProductCost(4000.0);
		product1.setProductDescription("good");
		product1.setProductName("Nilon Shirt");

		shop = new Shop();
		shop.setShopAverageRating(4.4);
		shop.setShopDescription("Fash");
		shop.setShopName("Brand fACTORY");
		shop.setShopLocation("Bangalore");

		productShopDetails = new ProductShopDetails();
		productShopDetails.setProduct(product);
		productShopDetails.setShop(shop);
	}

	@Test
	public void getProductsTest() {
		List<Product> products = new ArrayList<Product>();
		products.add(product);

		when(productRepository.findByProductNameContains(product.getProductName())).thenReturn(products);

		ProductResponse productResponse = productService.getProducts(product.getProductName());

		ProductResponse productResponseResponse = new ProductResponse(products, products.size());

		assertEquals(productResponseResponse.getProducts(), productResponse.getProducts());

		assertEquals(productResponseResponse.getProductListSize(), productResponse.getProductListSize());

		verify(productRepository, times(1)).findByProductNameContains(product.getProductName());

	}

	@Test
	public void testProductNameNotFoundException() {

		List<Product> products = new ArrayList<Product>();
		Mockito.when(productRepository.findByProductNameContains(product.getProductName())).thenReturn(products);
		assertThrows(ProductNameNotFoundException.class, () -> {
			productService.getProducts(product.getProductName());
		});
	}

	@Test
	public void testAirlineNotFoundException() {

		Mockito.when(productRepository.findById(1l)).thenReturn(Optional.empty());
		assertThrows(ProductNotFoundException.class, () -> {
			productService.getShopDetalis(1l);
		});
	}

}