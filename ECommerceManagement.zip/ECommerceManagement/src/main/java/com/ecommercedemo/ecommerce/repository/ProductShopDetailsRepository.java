package com.ecommercedemo.ecommerce.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ecommercedemo.ecommerce.entity.Product;
import com.ecommercedemo.ecommerce.entity.ProductShopDetails;

@Repository
public interface ProductShopDetailsRepository extends JpaRepository<ProductShopDetails, Long> {

	public ProductShopDetails findByShopShopIdAndProductProductId(Long productId, Long shopId);

	@Query("From ProductShopDetails where product=:product")
	public List<ProductShopDetails> findProductByProduct(Product product);

}
