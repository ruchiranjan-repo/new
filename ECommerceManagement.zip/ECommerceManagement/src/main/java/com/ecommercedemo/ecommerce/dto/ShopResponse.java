package com.ecommercedemo.ecommerce.dto;

import java.util.List;

import com.ecommercedemo.ecommerce.entity.Product;
import com.ecommercedemo.ecommerce.entity.Shop;
import com.fasterxml.jackson.annotation.JsonProperty;

/**
 * 
 * ShopResponse is used to send the Shop details
 * 
 * @author YaseenShaik
 *
 */
public class ShopResponse {

	@JsonProperty("product")
	private Product product;

	@JsonProperty("shops")
	private List<Shop> shops;

	@JsonProperty("shopListSize")
	private Integer shopsListSize;

	public List<Shop> getShops() {
		return shops;
	}

	public void setShops(List<Shop> shops) {
		this.shops = shops;
	}

	public Integer getShopsListSize() {
		return shopsListSize;
	}

	public void setShopsListSize(Integer shopsListSize) {
		this.shopsListSize = shopsListSize;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public ShopResponse(Product product, List<Shop> shops, Integer shopsListSize) {
		super();
		this.product = product;
		this.shops = shops;
		this.shopsListSize = shopsListSize;
	}
}
